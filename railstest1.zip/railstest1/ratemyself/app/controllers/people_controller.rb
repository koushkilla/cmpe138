class PeopleController < ApplicationController
def index
@people = Person.all.order("created_at DESC")
end
def show

end
def new
	@person = Person.new
end
def create
	@person = Person.new.(person_params)

	if @person.save
		redirect_to root_path
	else
		render 'new'
	end

end
private
def person_params
params.require(:person).permit(:title, :description, :author)
end

end
