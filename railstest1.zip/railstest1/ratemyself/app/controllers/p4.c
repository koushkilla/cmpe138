#ifdef __unix__
#include <unistd.h>
#elif defined _WIN32
# include <windows.h>
#define sleep(x) Sleep(1000 * x)
#endif
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *pingThread(void *vargp)
{
int i;
for(i=0;i<10;i++){
sleep(5);
printf("thread 1: ping\n");
}
   return NULL;
}

void *pongThread(void *vargp)
{
int i;
for(i=0;i<10;i++){
sleep(5);
printf("thread 2: pong\n");
return NULL;
}
}

int main()
{
   pthread_t tid;
   pthread_create(&tid, NULL, pingThread, NULL);
   pthread_join(tid, NULL);
   pthread_create(&tid, NULL, pongThread, NULL);
   pthread_join(tid, NULL);
   exit(0);
}